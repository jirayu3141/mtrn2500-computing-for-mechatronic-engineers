#include "beads.h"

String::String()
{
	Beads = 0;
}

String::String(int beads)
{
	Beads = beads;
}
int String::GetBeads()
{
	return Beads;
}

void String::SetBeads(int beads)
{
	Beads = beads;
}

// Non-member function
String AddABead(String& s)
{
	s.SetBeads(s.GetBeads()+1);

	return s;
}
