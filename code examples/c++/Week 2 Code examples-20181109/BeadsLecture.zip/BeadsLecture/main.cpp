#include <iostream>
#include "beads.h"
#include <conio.h>

using namespace std;

int main()
{
	String S;

	AddABead(AddABead(AddABead(S)));

	cout << S.GetBeads() << endl;
	_getch();
	return 0;
}
