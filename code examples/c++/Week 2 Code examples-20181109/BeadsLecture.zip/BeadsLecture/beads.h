#ifndef BEADS_H
#define BEADS_H
class String
{
	int Beads;

public:
	String();
	String(int beads);
	int GetBeads();
	void SetBeads(int beads);
};

String AddABead(String& s);
#endif
