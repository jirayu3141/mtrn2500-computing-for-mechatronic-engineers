#include <iostream>
#include <math.h>
#include "complex.h"

using namespace std;

Complex::Complex()
{
}

Complex::Complex(double real, double imag)
{
	Real = real;
	Imag = imag;
}

double Complex::Modulus()
{
	return(sqrt(Real*Real + Imag*Imag));
}

double Complex::Phase()
{
	return(atan2(Imag,Real));
}


void Complex::Print()
{
	cout << Real;
	if(Imag >= 0)
		cout << "+j" << Imag;
	else
		cout << "-j" << fabs(Imag);
	cout << endl;
}


Complex operator+(const Complex&a, const Complex& b)
{
	return Complex(a.Real+b.Real, a.Imag + b.Imag);
}

ostream& operator<<(ostream& os, const Complex& a)
{
	os << a.Real;
	if(a.Imag >= 0)
		os << "+j" << a.Imag;
	else
		os << "-j" << fabs(a.Imag);

	return os;
}

Complex operator++(Complex& c)
{
	++c.Real;
	++c.Imag;

	return c;
}


Complex operator++(Complex& c, int)
{
	Complex temp = c;
	c.Real++;
	c.Imag++;

	return temp;
}
