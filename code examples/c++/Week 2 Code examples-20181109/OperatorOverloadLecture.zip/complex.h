#ifndef COMPLEX_H
#define COMPLEX_H

#include <iostream>

using namespace std;

class Complex
{
private:
	double Real;
	double Imag;
public:
	Complex();// default constructor
	Complex(double real, double imag);
	double Modulus();
	double Phase();
	void Print();

	friend ostream& operator<<(ostream& os, const Complex& c);
	friend Complex operator+(const Complex& a, const Complex& b);
	
	
	friend Complex operator++(Complex& c);
	friend Complex operator++(Complex& c, int);
};


#endif