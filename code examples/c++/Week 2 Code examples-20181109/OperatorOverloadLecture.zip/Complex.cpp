#include <iostream>
#include "complex.h"
#include <conio.h>

using namespace std;
int main()
{
	Complex A(20.0, -15.0), B(1,1), C;

	cout << " A = " << A << endl;
	cout << " B = " << B << endl;

	C = A + B;

	cout << "C = A + B;"  << C << endl;

	cout << " ++C " << ++C << endl;

	C = A++;

	cout << "C = A++; " << C << endl;

	C = A;

	cout << "C = A; " << C << endl;
	_getch();
	return 0;
}


