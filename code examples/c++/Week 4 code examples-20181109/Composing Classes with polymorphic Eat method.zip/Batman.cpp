#include "Batman.h"


Batman::Batman()
{
	speed = 2;
	crime_fighting_efficiency = 3.14;
}

void Batman::Eat() {
	cout << "Batman eats blood" << endl;
}
