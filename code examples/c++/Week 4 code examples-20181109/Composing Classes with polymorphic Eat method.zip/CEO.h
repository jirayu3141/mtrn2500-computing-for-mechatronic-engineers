#pragma once

#include "Person.h"
#include <iostream>


class CEO : public Person
{
	string companyName;
	double moneyMakingEfficiency;
public:
	CEO();
//	void	Eat();
};