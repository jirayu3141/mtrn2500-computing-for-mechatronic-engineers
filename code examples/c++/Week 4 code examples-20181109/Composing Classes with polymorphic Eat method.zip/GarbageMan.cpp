#include "GarbageMan.h"


GarbageMan::GarbageMan()
{
	bins = 0;
	garbageEfficiency = .75;
}

