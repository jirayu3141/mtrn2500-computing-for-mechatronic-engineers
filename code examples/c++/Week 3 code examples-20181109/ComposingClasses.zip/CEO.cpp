#include "CEO.h"

CEO::CEO()
{
	companyName = "LikelyToFail";
	moneyMakingEfficiency = .1;
}