#pragma once

#include "Person.h"

class GarbageMan : public Person
{
	int bins;
	double garbageEfficiency;
public:
	GarbageMan();
};