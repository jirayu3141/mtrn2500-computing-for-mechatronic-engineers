#pragma once

#include "CEO.h"

class Batman : public CEO
{
	int speed;
	double crime_fighting_efficiency;
public:
	Batman();
};
