#include "Batman.h"

Batman::Batman()
{
	speed = 2;
	crime_fighting_efficiency = 3.14;
}